from pathlib import Path
import numpy as np,json,hashlib,gzip
p=Path(__file__).parent; a=np.load(p/'matrices.npz');cfg=json.loads((p/'exact18_config.json').read_text());f=cfg['b330_dedicated']['found'];assert f['distance']==18 and f['witness']['side']=='X'
witness=f['witness']['witness'];support=[]
for q,v in witness:
 for b in range(2):
  if v>>b&1:support.append(2*q+b)
x=np.zeros(1024,dtype=np.uint32);x[support]=1;assert int(x.sum())==18
HX=a['HX'].astype(np.uint32);HZ=a['HZ'].astype(np.uint32);LX=a['LX'].astype(np.uint32);LZ=a['LZ'].astype(np.uint32)
assert not np.any((HX@HZ.T)%2);assert not np.any((HZ@LX.T)%2);assert not np.any((HX@LZ.T)%2);assert np.array_equal(LX@LZ.T,np.eye(256,dtype=np.uint32))
syndrome=(HZ@x)%2;logical=(LZ@x)%2;assert not np.any(syndrome) and np.any(logical)
def packed(mat):return [int.from_bytes(row.tobytes(),'little') for row in np.packbits(mat,axis=1,bitorder='little')]
def basis(mat):
 b={}
 for q in packed(mat):
  while q:
   t=q.bit_length()-1
   if t in b:q^=b[t]
   else:b[t]=q;break
 return b
def rank(mat):return len(basis(mat))
assert rank(HX)==rank(HZ)==384;assert rank(np.vstack([HX,x]))==385
# Independently audit both distance inputs: their GF4 constraints have the
# same binary kernel, and their logical labels equal the binary pairing.
mul=np.array([[0,0,0,0],[0,1,2,3],[0,2,3,1],[0,3,1,2]],dtype=np.uint8)
for side,check,opp in [('X',HZ,LZ),('Z',HX,LX)]:
 vals=list(map(int,(p/f'distance_{side}.txt').read_text().split()));it=iter(vals);n,m,K,P=[next(it) for _ in range(4)];assert (n,m,K,P)==(512,192,4,64)
 M=np.zeros((2*m,2*n),dtype=np.uint8);labels=np.zeros((256,2*n),dtype=np.uint8)
 for q in range(n):
  edges=[(next(it),next(it)) for _ in range(3)]
  for c,coef in edges:
   for v in range(2):
    y=int(mul[coef,1<<v]);M[2*c,2*q+v]=y&1;M[2*c+1,2*q+v]=y>>1
  vv=[]
  for value in range(1,4):
   z=sum(next(it)<<(64*k) for k in range(K));vv.append(z)
  assert vv[0]^vv[1]==vv[2]
  for v in range(2):labels[:,2*q+v]=[(vv[v]>>k)&1 for k in range(256)]
 assert rank(M)==384 and rank(np.vstack([M,check]))==384
 assert np.array_equal(labels,opp)
 # Simultaneous cyclic symbol shifts are binary coordinate permutations.
 perm=np.array([2*(block*P+(q-1)%P)+bit for block in range(8) for q in range(P) for bit in range(2)])
 assert rank(np.vstack([check,check[:,perm]]))==384
# Re-audit full stage17 coverage from immutable events.
initial=json.loads((p/'stage17_jobs.json').read_text());last={};errors=[]
with gzip.open(p/'dedicated_final.jsonl.gz','rt') as src:
 for line in src:
  e=json.loads(line)
  if e['kind']=='d_result' and e['id'].startswith('w17_'):last[e['id']]=e
  if e['kind']=='d_error':errors.append(e)
assert not errors
def visit(k):
 e=last[k];r=e['result']
 if r['status']=='complete':assert r['complete'] and not r['found'] and r['frontier_size']==0;return 1
 assert r['status']=='split' and e['children'];return sum(visit(c) for c in e['children'])
leaves=sum(visit('w17_'+j['id']) for j in initial);assert len(initial)==4536 and leaves==6412
empty=[]
for side in ['X','Z']:
 for b in range(8):
  for v in range(1,4):
   name=f'{side}_b{b}_a{v}';ls=(p/f'full17_{name}.frontier').read_text().splitlines()
   expected=[j for j in initial if j['original_root']==name];assert [j['frontier'].splitlines()[1] for j in expected]==ls[1:]
   if not expected:empty.append(name)
assert len(empty)==6
out=json.loads((p/'audited_distance_bound.json').read_text());out.update(status='exact',distance=18,lower_bound=18,upper_bound=18,no_witness_through=17,exact_distance_verified=True,stage17={'original_roots':48,'empty_roots':empty,'initial_disjoint_partitions':4536,'complete_disjoint_leaves':leaves,'incomplete_leaves':0,'errors':[]},binary_witness={'side':'X','weight':18,'support_zero_based':support,'syndrome_weight':int(syndrome.sum()),'logical_pairing_nonzero_rows':np.flatnonzero(logical).tolist(),'outside_stabilizer_row_space':True,'GF4_symbol_values':witness},distance_input_kernel_and_label_agreement_verified=True,cyclic_symmetry_verified=True)
out['sha256'].update({name:hashlib.sha256((p/name).read_bytes()).hexdigest() for name in ['stage17_jobs.json','dedicated_final.jsonl.gz','exact18_config.json','verify_exact18.py']})
(p/'exact_distance18.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'distance':18,'support_zero_based':support,'syndrome_weight':int(syndrome.sum()),'logical_pairing_weight':int(logical.sum()),'complete_stage17_leaves':leaves,'binary_inputs_independently_verified':True}))
